const server = require("./server/core");
server.listen(80, () => console.log('app listening on port 80!'));